-------INSTALLATION--------
Put the vpk file of whichever weapon(s) you wish to replace in Team Fortress 2/tf/custom

-------CREDITS---------
DatGmann - Models, Textures & Promos
Extra Ram - Concept Art
Badgerpig - Technical Help
