-----------------------------------------
|		Packed with ItemToast v1.3.1	|
|				by BANG!				|
|			 www.bonkboy.com			|
-----------------------------------------


########### How to install VPK mods ##########

# MODs WITH  mod_name_Materials.vpk & 'Replacement_Models'

Copy the materials replacement VPK (mod_name_Materials.vpk) to:
 \Team Fortress 2\tf\custom\mod_name_Materials.vpk

Copy the model replacement(s) of your choice VPK (mod_name_item_name.vpk) to:
 \Team Fortress 2\tf\custom\mod_name_item_name.vpk


-----------------------------------------

# MODs WITH ONLY mod_name_item_name.vpk
Copy the model replacement(s) VPK (mod_name_item_name.vpk) to:
 \Team Fortress 2\tf\custom\mod_name_item_name.vpk


###########  How to find the 'Team Fortress 2' folder ###########

On Steam go to: Libary > Team Fortress 2
Right click on Team Fortress 2 > Properties
Local Files (Tab) > BROWSE LOCAL FILES...
